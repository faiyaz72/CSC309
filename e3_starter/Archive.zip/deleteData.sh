rm restaurants.json
rm reservations.json