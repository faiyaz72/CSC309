node app.js --addRest "Red Lobster" "Seafood at low prices"
node app.js --addResv  "Red Lobster" "Nov 17 2018 17:15:00" 5
node app.js --addResv  "Red Lobster" "Nov 17 2018 17:25:00" 5
node app.js --addResv  "Red Lobster" "Nov 17 2018 17:35:00" 5
node app.js --addDelay "Red Lobster" 60
node app.js --status
node app.js --addRest "PF Changs" "Chinese Bistro"
node app.js --addResv  "PF Changs" "Nov 17 2018 17:45:00" 5
node app.js --addResv  "PF Changs" "Nov 17 2018 17:55:00" 5
node app.js --addResv  "PF Changs" "Nov 17 2018 17:35:00" 5
node app.js --addResv  "PF Changs" "Nov 17 2018 17:25:00" 5
node app.js --addResv  "PF Changs" "Nov 17 2018 17:15:00" 5
node app.js --addResv  "PF Changs" "Nov 17 2018 17:05:00" 5
node app.js --status
node app.js --allRest
node app.js --restInfo "Red Lobster"
node app.js --allResv "Red Lobster"
node app.js --checkOff "Red Lobster"
node app.js --allResv "Red Lobster"
node app.js --hourResv "Nov 17 2018 16:40:00"

